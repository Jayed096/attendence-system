Gluon interface, not totally working.
